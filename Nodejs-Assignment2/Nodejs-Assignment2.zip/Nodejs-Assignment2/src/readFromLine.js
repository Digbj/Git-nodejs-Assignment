const prompt=require('prompt-sync')();
let name=prompt("Enter Your Name =>");
console.log('Hello '+ name)