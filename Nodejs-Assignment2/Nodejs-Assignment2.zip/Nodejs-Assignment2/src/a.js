require("dotenv").config();
console.log("USERNAME",process.env.env1)
process.env.env1='ghfhf';
console.log("hello "+USERNAME);