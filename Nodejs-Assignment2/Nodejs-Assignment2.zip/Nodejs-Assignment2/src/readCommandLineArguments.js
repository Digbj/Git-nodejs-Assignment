// console.log(process.argv);
let userName=process.argv[2];
console.log(`Hello ${userName}`)